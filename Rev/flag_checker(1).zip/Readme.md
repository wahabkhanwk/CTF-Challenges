# Recover the Flag

---

## Challenge Description

Uh oh! During the development of our latest challenges, we misplaced the flag for this one. Can you help us recover it? This should be an easy reverse engineering task for those familiar with Rust.

## Category

Reverse Engineering

## Difficulty

Easy

---
