Got a knack for cracking codes and a hankering for some sweet bounty? You've come to the right place, hotshot!
CTFBANK: The Case of the Missing Access
Challenge Description

Alright, listen up, folks! I was in the middle of cooking up the most secure, most efficient CTF transaction bank the world has ever seen: CTFBANK. Everything was going smoothly until... poof! I lost something crucial. Now I can't even get into my own system to grant access, and that's a problem for everyone.

Reverse Engineering
Difficulty

Medium


Deploy the verifiew on NC and give the binary to the USER
